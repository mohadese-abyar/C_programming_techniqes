#include <stdio.h>

int main() {
    int numbers[5] = {12, 45, 7, 89, 23};
    int max = numbers[0]; // فرض می‌کنیم اولین عدد، بزرگترین است

    for (int i = 1; i < 5; i++) {
        // اگر عدد فعلی در آرایه از max بزرگتر بود، max را آپدیت کن
        if ( numbers[i]> max ) {
            max = numbers[i];
        }
    }

    printf("Maximum number is: %d\n", max);

    return 0;
}
